﻿using System;
using System.Collections.Generic;
using System.Text;

namespace What_to_Wear.Models
{
    public class ListModel
    {
        public int ID { get; set; }

        public string Cloth { get; set; }
    }
}
