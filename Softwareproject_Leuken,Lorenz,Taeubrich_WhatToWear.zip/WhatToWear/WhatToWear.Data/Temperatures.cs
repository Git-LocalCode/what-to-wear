﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WhatToWear.Data
{
    public class Temperatures
    {
        public double TemperatureMax { get; set; }

        public double TemperatureMin { get; set; }
    }
}
