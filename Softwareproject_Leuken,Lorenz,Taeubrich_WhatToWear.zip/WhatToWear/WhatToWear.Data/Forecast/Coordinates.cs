﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WhatToWear.Data.Forecast
{
    public class Coordinates
    {
        public double Latitude { get; set; }

        public double Longitude { get; set; }
    }
}
