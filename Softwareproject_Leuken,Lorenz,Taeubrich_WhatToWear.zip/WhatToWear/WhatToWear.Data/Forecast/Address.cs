﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WhatToWear.Data.Forecast
{
    public class Address
    {
        public string City { get; set; }

        public string Country { get; set; }
    }
}
